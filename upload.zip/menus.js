exports.breakFirst = [
  {
    name: "目玉焼き",
  },
  {
    name: "食パン",
  }
]

exports.lunch = [
  {
    name: "ラーメン",
  },
  {
    name: "焼きそば",
  },
]

exports.dinner = [
  {
    name: "カレー",
  },
  {
    name: "オムライス",
  },
]
